

public class Config
{
	//public static int Penalty=10;
}
