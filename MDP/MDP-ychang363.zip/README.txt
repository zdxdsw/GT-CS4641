CS 4641 PROJECT4
Name: CHANG Yingshan
GT Account: ychang363
GT ID: 903457645

The code of this project originates from CMU's Reinforment Learning Simulator.
The original source can be found here: http://www.cs.cmu.edu/~awm/rlsim/

I downloaded the code from this github repository: https://github.com/iRapha/CS4641/tree/master/P4

The compiled lr.jar is included in my submission, along with the source. 

To run RLSim, navigate to the folder that contains rl.jar and type the following in the terminal:
	 java -cp rl.jar MainUI

This starts the UI of RLSim. To reproduce my result, please choose an algorithm, load maze and set the parameters, then start execution. I used #1 maze for my Simple Maze and #6 maze for my Complex maze.